<?php

namespace owonico\manager;

/*---------------------------------
basic core uses
---------------------------------*/

use owonico\{Main, Variables};
use owonico\manager\{PlayerManager, RankManager};

/*---------------------------------
basic libs uses
---------------------------------*/

use maipian\webhook\Embed;
use maipian\webhook\Message;
use maipian\webhook\Webhook;
use maipian\form\pmforms\MenuForm;
use maipian\form\pmforms\MenuOption;
use maipian\form\pmforms\FormIcon;
use maipian\form\formapi\SimpleForm;
use maipian\form\pmforms\ModalForm;
use maipian\form\formapi\CustomForm;
use maipian\scoreboard\Scoreboard;
use vixikhd\duels5\arena\Arena;
use maipian\query\PMQuery;
use maipian\query\PmQueryException;

/*---------------------------------
basic pocketmine uses
---------------------------------*/

use pocketmine\entity\Skin;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class FormManager{

    public static function getFFAForm(): MenuForm{
        return new MenuForm(
            "§b" . "§fFREE FOR ALL",
            "",
            [
                new MenuOption("§bNodebuff\n§7 " . Main::getWorldCount(Variables::Nodebuffffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/nodebuff.png", FormIcon::IMAGE_TYPE_PATH)),
            /*    new MenuOption("§b Combo\n§7 " . Main::getWorldCount(Variables::Comboffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/combo.png", FormIcon::IMAGE_TYPE_PATH)),*/
                new MenuOption("§b Fist\n§7 " . Main::getWorldCount(Variables::Fistffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/fist.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Sumo\n§7 " . Main::getWorldCount(Variables::Sumoffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/sumo.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Gapple\n§7 " . Main::getWorldCount(Variables::Gappleffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/gapple.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b KnockBack\n§7 " . Main::getWorldCount(Variables::Knockffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/knock.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Resistance\n§7 " . Main::getWorldCount(Variables::Resistanceffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/resistance.png", FormIcon::IMAGE_TYPE_PATH)),
              /*  new MenuOption("§b Build\n§7 " . Main::getWorldCount(Variables::Buildffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/build.png", FormIcon::IMAGE_TYPE_PATH)),
             */ new MenuOption("§b Midfight\n§7 " .  Main::getWorldCount(Variables::Midfightffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/combo.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Skywars\n§7 " .  Main::getWorldCount(Variables::Skywarsffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/build.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b BuildUHC\n§7 " .  Main::getWorldCount(Variables::Builduhcffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/uch.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Nodebuffffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "NodebuffFFA";
                        PlayerManager::sendNodebuffKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                  /*  case 1:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Comboffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "ComboFFA";
                        PlayerManager::sendComboKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break; */
                    case 1:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Fistffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "FistFFA";
                        PlayerManager::sendFistKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 2:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Sumoffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "SumoFFA";
                        PlayerManager::sendSumoKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 3:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Gappleffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "GappleFFA";
                        PlayerManager::sendGappleKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 4:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Knockffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "KnockFFA";
                        PlayerManager::sendKnockKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 5:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Resistanceffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "ResistanceFFA";
                        PlayerManager::sendResistanceKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    /*case 7:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Buildffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "BuildFFA";
                        PlayerManager::sendBFFAKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;*/
                    case 6:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Midfightffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "MidfightFFA";
                        PlayerManager::sendMidfightKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 7:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Skywarsffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "SkywarsFFA";
                        PlayerManager::sendSkywarsKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;
                    case 8:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Builduhcffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "BuildUHCFFA";
                        PlayerManager::sendBuildUHCKit($player);
                        $player->setGamemode(Gamemode::SURVIVAL());
                        break;
                }
            },

            function (Player $submitter): void{
                //I dont want to handle when his close the form
            }
        );
    }
    public static function getSpectateForm(Player $player): MenuForm{
      return new MenuForm(
          "§7Spectate",
          "",
          [
                new MenuOption("§aFFAS", new FormIcon("quza/textures/ui/quza_ui/ffa.png", FormIcon::IMAGE_TYPE_PATH)),              
              ],
          function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->sendForm(self::getSpecFormFfa($player));
                        break;                        
                }
            },

            function (Player $submitter): void{
                //I dont want to handle when his close the form
            }
        );
    }
    public static function getSpecFormFfa(Player $player): MenuForm{
      return new MenuForm(
          "§7FFAS",
          "",
          [
              new MenuOption("§bNodebuff\n§7 " . Main::getWorldCount(Variables::Nodebuffffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/nodebuff.png", FormIcon::IMAGE_TYPE_PATH)),
            /*    new MenuOption("§b Combo\n§7 " . Main::getWorldCount(Variables::Comboffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/combo.png", FormIcon::IMAGE_TYPE_PATH)),*/
                new MenuOption("§b Fist\n§7 " . Main::getWorldCount(Variables::Fistffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/fist.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Sumo\n§7 " . Main::getWorldCount(Variables::Sumoffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/sumo.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Gapple\n§7 " . Main::getWorldCount(Variables::Gappleffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/gapple.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b KnockBack\n§7 " . Main::getWorldCount(Variables::Knockffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/knock.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Resistance\n§7 " . Main::getWorldCount(Variables::Resistanceffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/resistance.png", FormIcon::IMAGE_TYPE_PATH)),
              /*  new MenuOption("§b Build\n§7 " . Main::getWorldCount(Variables::Buildffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/build.png", FormIcon::IMAGE_TYPE_PATH)),
             */ new MenuOption("§b Midfight\n§7 " .  Main::getWorldCount(Variables::Midfightffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/combo.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b Skywars\n§7 " .  Main::getWorldCount(Variables::Skywarsffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/build.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§b BuildUHC\n§7 " .  Main::getWorldCount(Variables::Builduhcffa) . "§7 Playing", new FormIcon("quza/textures/ui/ui_png/uch.png", FormIcon::IMAGE_TYPE_PATH))
              ],
          function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Nodebuffffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "NodebuffFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 1:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Fistffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "FistFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 2:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Sumoffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "SumoFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 3:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Gappleffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "GappleFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 4:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Knockffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "KnockFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 5:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Resistanceffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "ResistanceFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    /*case 7:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Buildffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "BuildFFA";
                        PlayerManager::sendBFFAKit($player);
                        $player->setGamemode(GameMode::SURVIVAL());
                        break;*/
                    case 6:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Midfightffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "MidfightFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 7:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Skywarsffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "SkywarsFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(GameMode::SPECTATOR());
                        break;
                    case 8:
                        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName(Variables::Builduhcffa)->getSafeSpawn());
                        Main::$playerArena[$player->getName()] = "BuildUHCFFA";
                        PlayerManager::sendSpectateKit($player);
                        $player->setGamemode(Gamemode::SPECTATOR());
                        break;
                }
            },

            function (Player $submitter): void{
                //I dont want to handle when his close the form
            }
        );
    }
    public static function getSettingsForm(Player $player): MenuForm{
        $cps = new Config(Main::getInstance()->getDataFolder() . "settings/CPSPopup.yml", Config::YAML);
        $hitParticles = new Config(Main::getInstance()->getDataFolder() . "settings/HitParticles.yml", Config::YAML);
        $autoSprint = new Config(Main::getInstance()->getDataFolder() . "settings/AutoSprint.yml", Config::YAML);
        $scoreboard = new Config(Main::getInstance()->getDataFolder() . "settings/Scoreboard.yml", Config::YAML);
        $arenaRespawn = new Config(Main::getInstance()->getDataFolder() . "settings/ArenaRespawn.yml", Config::YAML);
        if (SettingsManager::getCpsEnabled($player)) {
            $cpsStatus = "§bCPS Popup\n§aEnabled";
        } else {
            $cpsStatus = "§bCPS Popup\n§cDisabled";
        }
        if (SettingsManager::getHitEffectEnabled($player)) {
            $hitStatus = "§bHit Effect\n§aEnabled";
        } else {
            $hitStatus = "§bHit Effect\n§cDisabled";
        }
        if (SettingsManager::getAutoSprintEnabled($player)) {
            $autoStatus = "§bAuto Sprint\n§aEnabled";
        } else {
            $autoStatus = "§bAuto Sprint\n§cDisabled";
        }
        if (SettingsManager::getArenaRespawnEnabled($player)) {
            $arenaStatus = "§bArena Respawn\n§aEnabled";
        } else {
            $arenaStatus = "§bArena Respawn\n§cDisabled";
        }
        /*if (SettingsManager::getScoreboardEnabled($player)) {
            $scoreStatus = "§bScoreboard\n§aEnabled";
        } else {
            $scoreStatus = "§bScoreboard\n§cDisabled";
        }*/

        return new MenuForm(
            "§7SETTINGS",
            "",
            [
                new MenuOption($cpsStatus, new FormIcon("quza/textures/ui/ui_png/settings.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption($hitStatus, new FormIcon("quza/textures/ui/ui_png/settings.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption($autoStatus, new FormIcon("quza/textures/ui/ui_png/settings.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption($arenaStatus, new FormIcon("quza/textures/ui/ui_png/arenarespawn.png", FormIcon::IMAGE_TYPE_PATH))
                //new MenuOption($scoreStatus, new FormIcon("quza/textures/ui/ui_png/settings.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $submitter, int $selected) use ($cps, $autoSprint, $hitParticles, $scoreboard, $arenaRespawn): void{
                switch ($selected){
                    case 0:
                        if (SettingsManager::getCpsEnabled($submitter)){
                            //$cps->remove($submitter->getXuid());
                            //$cps->save();
                            SettingsManager::setCpsEnabled($submitter, false);

                            $submitter->sendMessage(Variables::Prefix . "§aDisabled CPS Popup");
                        } else{
                            //$cps->set($submitter->getXuid(), true);
                            //$cps->save();
                            SettingsManager::setCpsEnabled($submitter, true);

                            $submitter->sendMessage(Variables::Prefix . "§aEnabled CPS Popup");
                        }
                        break;
                    case 1:
                        if (SettingsManager::getHitEffectEnabled($submitter)){
                            //$hitParticles->remove($submitter->getXuid());
                            //$hitParticles->save();
                            SettingsManager::setHitEffectEnabled($submitter, false);

                            $submitter->sendMessage(Variables::Prefix . "§aDisabled Hit Effect");
                        } else{
                            //$hitParticles->set($submitter->getXuid(), true);
                            //$hitParticles->save();
                            SettingsManager::setHitEffectEnabled($submitter, true);

                            $submitter->sendMessage(Variables::Prefix . "§aEnabled Hit Effect");
                        }
                        break;
                     case 2:
                        if (SettingsManager::getAutoSprintEnabled($submitter)){
                            //$autoSprint->remove($submitter->getXuid());
                            //$autoSprint->save();
                            SettingsManager::setAutoSprintEnabled($submitter, false);

                            $submitter->sendMessage(Variables::Prefix . "§aDisabled Auto Sprint");
                        } else{
                            //$autoSprint->set($submitter->getXuid(), true);
                            //$autoSprint->save();
                            SettingsManager::setAutoSprintEnabled($submitter, true);

                            $submitter->sendMessage(Variables::Prefix . "§aEnabled Auto Sprint");
                        }
                        break;
                        case 3:
                        if (SettingsManager::getArenaRespawnEnabled($submitter)){
                            //$autoSprint->remove($submitter->getXuid());
                            //$autoSprint->save();
                            SettingsManager::setArenaRespawnEnabled($submitter, false);

                            $submitter->sendMessage(Variables::Prefix . "§aDisabled Arena Respawn");
                        } else{
                            //$autoSprint->set($submitter->getXuid(), true);
                            //$autoSprint->save();
                            SettingsManager::setArenaRespawnEnabled($submitter, true);

                            $submitter->sendMessage(Variables::Prefix . "§aEnabled Arena Respawn");
                        }
                        break;
                    /*case 3:
                        if (SettingsManager::getScoreboardEnabled($submitter)){
                            //$scoreboard->set($submitter->getXuid(), false);
                            //$scoreboard->save();
                            SettingsManager::setScoreboardEnabled($submitter, false);

                            Main::$scoreboardEnabled[$submitter->getName()] = false;
                            Scoreboard::remove($submitter);

                            $submitter->sendMessage(Variables::Prefix . "§aDisabled Scoreboard");
                        } else{
                            //$scoreboard->set($submitter->getXuid(), true);
                            //$scoreboard->save();
                            SettingsManager::setScoreboardEnabled($submitter, true);

                            Main::$scoreboardEnabled[$submitter->getName()] = true;

                            $submitter->sendMessage(Variables::Prefix . "§aEnabled Scoreboard");
                        }
                        break;*/
                }
            },
            function (Player $submitter): void{

            }
        );
    }

    public static function getRuleForm(): MenuForm{
        return new MenuForm(
            "§eWelcome to §l§eLithiumMC",
            Main::getRuleContent(),
            [
                new MenuOption("§aAgree"),
                new MenuOption("§cDisagree")
            ],
            function(Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->sendMessage(Variables::Prefix . "§aHave Fun!");
                        break;
                    case 1:
                        $player->kick("§cYou must agree on the rule to play on server!");
                        break;
                }
            },
            function (Player $selecter): void{
                //$selecter->kick("§cYou must agree on the rule to play on server!");
            }
        );
    }

    public static function getCapeForm(): MenuForm{
        return new MenuForm(
            "§bCosmetics",
            "",
            [
                new MenuOption("§aPurchase", new FormIcon("quza/textures/ui/ui_png/cancel.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§aYour Cosmetics", new FormIcon("quza/textures/ui/quza_ui/on.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§aTrade Menu", new FormIcon("quza/textures/ui/quza_ui/trade.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§aRecycle Cosmetics", new FormIcon("quza/textures/ui/quza_ui/recycle.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected) : void{
                switch ($selected){
                    case 0:
                        $player->sendForm(self::getPurchaseCosForm($player));
                        break;
              /*          $pdata = new Config(Main::getInstance()->getDataFolder() . "capes/data.yml", Config::YAML);
                        $oldSkin = $player->getSkin();
                        $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), "", $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

                        $player->setSkin($setCape);
                        $player->sendSkin();

                        if($pdata->get($player->getXuid()) !== null){
                            $pdata->remove($player->getXuid());
                            $pdata->save();
                        }

                        $player->sendMessage(Variables::Prefix . "§aRemoved your cape!");
                        break;*/
                    case 1:
                        $player->sendForm(self::getOwnedForm($player));
                        break;
                    case 2:
                        $player->sendForm(self::getTradeMenuForm($player));
                        break;
                    case 3:
                        $player->sendForm(self::getRecycleForm($player));
                        break;
                }
            },
            function (Player $submiter): void{

            }
        );
    }
    public static function getPurchaseCosForm(): MenuForm{
        return new MenuForm(
            "§7Purchase A Cosmetic",
            "",
            [
                new MenuOption("§bArtifacts", new FormIcon("quza/textures/ui/quza_ui/artifacts.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§bCapes", new FormIcon("quza/textures/ui/quza_ui/capes.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->sendForm(self::getArtifactBuyForm());
                        break;                        
                    case 1:
                        $player->sendForm(self::getBuyCapeForm());
                        break;
                }
            },
            function (Player $player): void{

            }
        );
    }
    public static function getArtifactBuyForm(): MenuForm{
        return new MenuForm(
            "§7Artifacts",
            "",
            [
                new MenuOption("§bArt1", new FormIcon("quza/textures/ui/quza_ui/artifact.png", FormIcon::IMAGE_TYPE_PATH))
             ],
           function (Player $player, int $selected): void{
                switch($selected){
                    case 0:
                        $player->sendForm(self::R());
                        break;
                }
            },
            function (Player $player): void{
            }
        );
    }
    public static function getOwnedForm(): MenuForm{
        return new MenuForm(
            "§7Purchase A Cosmetic",
            "",
            [
                new MenuOption("§bArtifacts", new FormIcon("quza/textures/ui/quza_ui/artifacts.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§bCapes", new FormIcon("quza/textures/ui/quza_ui/capes.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->sendForm(self::getOwnedArtifactForm());
                        break;                        
                    case 1:
                        $player->sendForm(self::getCapeListForm());
                        break;
                }
            },
            function (Player $player): void{

            }
        );
    }
    public static function getOwnedArtifactForm(): MenuForm{
        return new MenuForm(
            "§7Artifacts",
            "",
            [
               new MenuOption("§bA1", new FormIcon("quza/textures/ui/quza_ui/artifact.png", FormIcon::IMAGE_TYPE_PATH))
                ],
            function (Player $player, int $selected): void{
              switch($selected){
                  case 0:
                      $player->sendForm(self::R());
                      break;
                }
            },
            function (Player $player): void{
            }
        );
    }
    public static function getCosmeticForm(): MenuForm{
        return new MenuForm(
            "§bCosmetics",
            "",
            [
                new MenuOption("§7Cosmetics", new FormIcon("quza/textures/ui/quza_ui/cape.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->sendForm(self::getCapeForm());
                        break;
                }
            },
            function (Player $player): void{
            }
        );
    }

    public static function getBuyCapeForm(string $capeName){
        $form = new ModalForm("Purchase - Cape", "§bYou didnt buy this cape yet, Do you want to purchase it now?\n\n§bCape: §6{$capeName}\n§bPrice: §a" . CosmeticsManager::getPriceFromCapeName($capeName) . " Coins", function(Player $player, bool $choice) use ($capeName) : void{

            $config = CosmeticsManager::getConfigFromCapeName($capeName);

            if($config == null) return;

            $price = CosmeticsManager::getPriceFromCapeName($capeName);

            if($choice){
                if(PlayerManager::getPlayerCoin($player) >= $price){
                    PlayerManager::reducePlayerCoin($player, $price);

                    $config->set($player->getXuid(), true);
                    $config->save();

                    $player->sendMessage(Variables::Prefix . "§aPurchased cape §b" . $capeName);
                } else {
                    $player->sendMessage(Variables::Prefix . "§cYou dont have enough money to purchase this!");
                }
            } else {
                //NOOP
            }

        }, "§aConfirm", "§cCancel");

        return $form;
    }

    public static function getCapeListForm(Player $player): SimpleForm{
        $form = new SimpleForm(function (Player $player, $data = null){
            $result = $data;

            if(is_null($result)) {
                return true;
            }

            $cape = $data;
            $pdata = new Config(Main::getInstance()->getDataFolder() . "capes/data.yml", Config::YAML);

            if(!file_exists(Main::getInstance()->getDataFolder() . "capes/" . $data . ".png")) {
                $player->sendMessage(Variables::Prefix . "§cThe chosen skin is not available!");
            } else {

                if(CosmeticsManager::ownedCape($player, $cape)){
                    $oldSkin = $player->getSkin();
                    $capeData = Main::getInstance()->createCape($cape);
                    $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

                    $player->setSkin($setCape);
                    $player->sendSkin();

                    $player->sendMessage(Variables::Prefix . "§aChanged your cape to " . $cape);

                    $pdata->set($player->getXuid(), $cape);
                    $pdata->save();
                } else {
                    $player->sendForm(self::getBuyCapeForm($cape));
                }
            }
        });
        $form->setTitle(" ");
        foreach(Main::getInstance()->getAllCapes() as $capes) {
            $form->addButton("§b" . CosmeticsManager::getCapeFormText($player, $capes), -1, "quza/textures/ui/ui_png/cape.png", $capes);
        }
        return $form;
    }

    /*public static function getRankForm(){
        $form = new SimpleForm(function (Player $player, int $data = null) {
            if ($data === null) {
                return true;
            }
            switch($data){
                case 0:
                    $shopvip = new Config($this->getDataFolder() . "rank\Rank.yml", Config::YAML);
                    if ($shopvip->exists($player->getXuid())){
                        RankManager::setPlayerRank($player, VIP);
                        $player->sendMessage("You was changed the ranked to VIP");
                    } else {
                        $shopvipForm = new ModalForm("VIP Rank");
                        $shopvipForm->setAccpeyText("Buy");
                        $shopvipForm->setDenyText("No");

                        $shopvipForm->setAccpetListener(function (Player $player){
                            $price = 600;
                            $shopvipForm = new Config($this->getDataFolder() . "shop\Rank.yml", Config::YAML);
                            if (PlayerManager::getPlayerCoin($player) >= $price){
                                PlayerManager::reducePlayerCoin($player, $price);
                                $player->sendMessage("§aSuccessfully bought VIP");
                                $shopvipForm->set($player->getXuid(), true);
                                $shopvipForm->save();
                            } else{
                                $player->sendMessage("§cYou dont have enough money!");
                            }
                        });
                    }
            }
        });
        $form->setTitle("Rank");
        $form->addButton("VIP");

        return $form;
    }*/


    public static function getDuelForm(): MenuForm{
        return new MenuForm(
            "",
            "",
            [
                new MenuOption("§bUnranked", new FormIcon("quza/textures/ui/ui_png/unranked_duel.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§bRanked", new FormIcon("quza/textures/ui/ui_png/ranked_duel.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        //$player->sendMessage(Variables::Prefix . "§aComing Soon...");
                        $player->sendForm(self::getUnrankedForm());
                        break;
                    case 1:
                        $player->sendMessage(Variables::Prefix . "§aComing Soon...");
                        //$player->sendForm(self::getRankedForm());

                        break;
                }
            },
            function (Player $selector): void{

            }
        );
    }

    public static function getUnrankedForm(): MenuForm{

        $duel = Main::getInstance()->getServer()->getPluginManager()->getPlugin("Unranked-Sumo");
        $duel2 = Main::getInstance()->getServer()->getPluginManager()->getPlugin("Unranked-Fist");

        return new MenuForm(
            "§b" . "§fUNRANKED DUEL",
            "",
            [
                new MenuOption("Nodebuff\n§7 " , /*\vixikhd\duels3\arena\Arena::$queue3 . " §7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/nodebuff.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("Sumo\n§7 " , /*Arena::$queue . " §7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/sumo.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("Fist\n§7 " , /*\vixikhd\duels2\arena\Arena::$queue2 . " §7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/fist.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Topfight\n§7 ", /*vixikhd\duels4\arena\Arena::$queue4 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/topfight.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("Bridge\n§7 " , /*vixikhd\duels5\arena\Arena::$queue5 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/bridge.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("Midfight\n§7 " , /*vixikhd\duels6\arena\Arena::$queue6 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/combo.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Bedwars\n§7 " , /*vixikhd\duels7\arena\Arena::$queue7 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/bedwars.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Bridgefight\n§7 " , /*vixikhd\duels8\arena\Arena::$queue8 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/bridgefight.png", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("Boxing\n§7 " , /*vixikhd\duels9\arena\Arena::$queue9 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/boxing.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Blockin\n§7 " , /*vixikhd\duels10\arena\Arena::$queue10 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/blockin.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Mlgrush\n§7 " , /*vixikhd\duels11\arena\Arena::$queue11 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/mlgrush.png", FormIcon::IMAGE_TYPE_PATH)),
                //new MenuOption("Skywars\n§7 " , /*vixikhd\duels12\arena\Arena::$queue12 . "§7Queuing",*/ new FormIcon("quza/textures/ui/ui_png/skywars.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->getServer()->dispatchCommand($player, "dl3 random");

                        break;
	                case 1:
                        $player->getServer()->dispatchCommand($player, "dl random");

                        break;
                    case 2:
                        $player->getServer()->dispatchCommand($player, "dl2 random");
                        
                        break;
                    case 3:
                        $player->getServer()->dispatchCommand($player, "unrankedbridge random");
                        
                        break;
                    case 4:
                        $player->getServer()->dispatchCommand($player, "dl5 random");
                        
                        break;
                    case 5:
                        $player->getServer()->dispatchCommand($player, "bxdl3 random");
                        
                        break;
                  /*  case 6:
                        $player->getServer()->dispatchCommand($player, "dl7 random");

                        break;
                    case 7:
                        $player->getServer()->dispatchCommand($player, "dl8 random");
                        
                        break;
                    case 8:
                        $player->getServer()->dispatchCommand($player, "bxdl3 random");
                        
                        break;
                    case 9:
                        $player->getServer()->dispatchCommand($player, "dl10 random");
                        
                        break;
                    case 10:
                        $player->getServer()->dispatchCommand($player, "dl11 random");
                        
                        break;
                    case 11:
                        $player->getServer()->dispatchCommand($player, "dl12 random");
                        
                        break;*/
                }
            },
            function (Player $selector): void{

            }
        );
    }

    public static function getRankedForm(): MenuForm{
        return new MenuForm(
            "§b",
            "",
            [
                new MenuOption("§cNodebuff"),
                new MenuOption("§bSumo"),
                new MenuOption("§eThe Bridge")
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->getServer()->dispatchCommand($player, "unrankednodebuff random");

                        break;
                    case 1:
                        $player->getServer()->dispatchCommand($player, "unrankedsumo random");

                        break;
                    case 2:
                        $player->getServer()->dispatchCommand($player, "tb random");
                        break;
                }
            },
            function (Player $selector): void{

            }
        );
    }

    public static function getRegionMenu(Player $player){
        $form = new SimpleForm(function(Player $player, int $data = null){
            if($data === null)
            {
                return true;
            }
            switch($data){
                case 0:
                    $player->sendMessage(Variables::Prefix . "§cServer Offline");
                    break;
            }
        });
        $form->setTitle("§b");
        $form->addButton("§bUSA [NA]\n§cOffline", 0, "quza/textures/ui/ui_png/region.png");
        $player->sendForm($form);
        return $form;
    }

    public static function getServerForm(): MenuForm{
        return new MenuForm(
            "§b",
            "",
            [
                new MenuOption("§bNA Region", new FormIcon("quza/textures/ui/ui_png/hyperiummc.png", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $player, int $selected): void{
                switch ($selected){
                    case 0:
                        $player->transfer("na.lithiummc.fun", 19130);

                        break;
                }
            },
            function (Player $selector): void{

            }
        );
    }

    public static function getReportForm()
    {

        $form = new CustomForm(function (Player $player, array $data = null){
            if($data === null){
                return true;
            }
            if($data[0] === null){
                $player->sendMessage(Variables::Prefix . "§cType Name");
                return true;
            }
            if($data[1] === null){
                $player->sendMessage(Variables::Prefix . "§cType Reason");
            }

            $player->sendMessage(Variables::Prefix . "§aSuccess sumbit the reports to staff group !");

            $webhook = new Webhook("" . Main::getInstance()->getConfig()->get("report-webhook"));
            $embed = new Embed();
            $embed->setTitle("New Report - " . Main::getInstance()->getConfig()->get("region"));
            $embed->addField("Name: ", $data[0]);
            $embed->addField("Reason: ", $data[1]);
            $embed->addField("Reporter: ", $player->getName());
            $embed->setFooter("Made by Kakashi");
            $embed->setTimestamp(new \DateTime("now"));
            $embed->setColor(0xF9F202);
            $message = new Message();
            $message->addEmbed($embed);
            $webhook->send($message);

        });
        $form->setTitle("");
        $form->addInput("§bName§f:");
        $form->addInput("§bReason§f:");
        return $form;
    }

    public static function getStatsForm($player)
    {
        $form = new SimpleForm(function (Player $player, int $data = null){
            if($data === null){
                return true;
            }

            switch($data){

            }
        });
        $form->setTitle("");
        $form->setContent("\n§bName§f: " . $player->getName() . "\n\n§bKills§f: " . PlayerManager::getPlayerKill($player) . "\n\n§bDeaths§f: " . PlayerManager::getPlayerDeath($player) . "\n\n§bElo§f: " . PlayerManager::getPlayerElo($player) ."\n\n§bRank§f: " . RankManager::getPlayerRank($player)->getName() . "\n\n§bCoins§f: " . PlayerManager::getPlayerCoin($player));
        return $form;
    }
}