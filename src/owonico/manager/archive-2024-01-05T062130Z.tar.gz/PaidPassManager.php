<?php

namespace owonico\manager;

use owonico\{Main, query\async\AsyncQuery, Variables};
use owonico\provider\MySQL;

use function int;

class PaidPassManager{

public static function getPlayerPass(Player $player){

        return Main::$userdata[$player->getName()]["Pass"] ?? -1;
    }

    public static function addPlayerPass(Player $player, int $amount){

        MySQL::getDatabase()->query("UPDATE UData SET Pass=" . (self::getPlayerPass($player) + $amount) . " WHERE Name='" . $player->getName() . "';");

        Main::$userdata[$player->getName()]["Pass"] = self::getPlayerPass($player) + $amount;

    }

    public static function reducePlayerPass(Player $player, int $pass){

        MySQL::getDatabase()->query("UPDATE UData SET Pass=" . (self::getPlayerPass($player) - $pass) . " WHERE Name='" . $player->getName() . "';");

        Main::$userdata[$player->getName()]["Pass"] = self::getPlayerPass($player) - $pass;

    }
}