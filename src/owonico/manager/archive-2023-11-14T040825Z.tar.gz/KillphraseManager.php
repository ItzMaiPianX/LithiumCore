<?php

namespace owonico\manager;

use owonico\Main;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class KillphraseManager{


    public static function getKillphraseFormText(Player $player, string $kpName){
        $ownedPath = Main::getInstance()->getDataFolder() . "owned/";
        
        $ownedkp = new Config($ownedPath . "OwnedKP.yml", Config::YAML); //1500
        $cry = new Config($ownedPath . "CryKP.yml", Config::YAML); //2000
        $fate = new Config($ownedPath . "FateKP.yml", Config::YAML); //2300
        $forget = new Config($ownedPath . "ForgetKP.yml", Config::YAML); //2500
        $love = new Config($ownedPath . "LoveKP.yml", Config::YAML); //3000
        $blew = new Config($ownedPath . "BlewKP.yml", Config::YAML); // 3300

        switch($kpName){
            case "Owned":
                $status = $ownedkp->exists($player->getXuid()) ? "" : self::getPriceColor($player, 1500) . "- 1500 §6Coins";

                return "Owned {$status}";
                break;
            case "Cry":
                $status = $cry->exists($player->getXuid()) ? "" : self::getPriceColor($player, 2000) . "- 2000 §6Coins";
    
                return "Cry {$status}";
                break;    
            case "Fate":
                $status = $fate->exists($player->getXuid()) ? "" : self::getPriceColor($player, 2300) . "- 2300 §6Coins";
    
                return "Fate {$status}";
                break;    
            case "Forget":
                $status = $forget->exists($player->getXuid()) ? "" : self::getPriceColor($player, 2500) . "- 2500 §6Coins";
    
                return "Forget {$status}";
                break;
            case "Love":
                $status = $love->exists($player->getXuid()) ? "" : self::getPriceColor($player, 3000) . "- 3000 §6Coins";
    
                return "Love {$status}";
                break;
            case "Blew":
                $status = $blew->exists($player->getXuid()) ? "" : self::getPriceColor($player, 3300) . "- 3300 §6Coins";
    
                return "Blew {$status}";
                break;    
                
            default: 
                return $kpName;
                break;    
        }

    }

    public static function ownedKp(Player $player, string $kpName){
        $ownedPath = Main::getInstance()->getDataFolder() . "owned/";
        
        $ownedkp = new Config($ownedPath . "OwnedKP.yml", Config::YAML); //1500
        $cry = new Config($ownedPath . "CryKP.yml", Config::YAML); //2000
        $fate = new Config($ownedPath . "FateKP.yml", Config::YAML); //2300
        $forget = new Config($ownedPath . "ForgetKP.yml", Config::YAML); //2500
        $love = new Config($ownedPath . "LoveKP.yml", Config::YAML); //3000
        $blew = new Config($ownedPath . "BlewKP.yml", Config::YAML); // 3300

        switch($kpName){
            case "Owned":
                return $ownedkp->exists($player->getXuid());

                break;
            case "Cry":
                return $cry->exists($player->getXuid());
    
                break;    
            case "Fate":
                return $fate->exists($player->getXuid());
    
                break;    
            case "Forget":
                return $forget->exists($player->getXuid());
    
                break;
            case "Love":
                return $love->exists($player->getXuid());
    
                break;
            case "Blew":
                return $blew->exists($player->getXuid());
    
                break;    
            default: 
                return true;
                break;    
        }
    }

    public static function getConfigFromKPName(string $kpName){
        $ownedPath = Main::getInstance()->getDataFolder() . "owned/";
        
        $ownedkp = new Config($ownedPath . "OwnedKP.yml", Config::YAML); //1500
        $cry = new Config($ownedPath . "CryKP.yml", Config::YAML); //2000
        $fate = new Config($ownedPath . "FateKP.yml", Config::YAML); //2300
        $forget = new Config($ownedPath . "ForgetKP.yml", Config::YAML); //2500
        $love = new Config($ownedPath . "LoveKP.yml", Config::YAML); //3000
        $blew = new Config($ownedPath . "BlewKP.yml", Config::YAML); // 3300

        switch($capeName){
            case "Owned":
                return $ownedkp;

                break;
            case "Cry":
                return $cry;
    
                break;    
            case "Fate":
                return $fate;
    
                break;    
            case "Forget":
                return $forget;
    
                break;
            case "Love":
                return $love;
    
                break;
            case "Blew":
                return $blew;
    
                break;    
            default: 
                return null;
                break;    
        }
    }

    public static function getPriceFromKPName(string $kpName){

        switch($kpName){
            case "Owned":
                return 1500;

                break;
            case "Cry":
                return 2000;
    
                break;    
            case "Fate":
                return 2300;
    
                break;    
            case "Forget":
                return 2500;
    
                break;
            case "Love":
                return 3000;
    
                break;
            case "Blew":
                return 3300;
    
                break;    
            default: 
                return 0;
                break;    
        }
    }

    public static function getPriceColor(Player $player, int $price){

        $coin = PlayerManager::getPlayerCoin($player);

        if($coin >= $price){
            return "§a";
        } else {
            return "§c";
        } 
    }
} 