<?php

declare(strict_types = 1);

namespace maipian\form\formapi;

use pocketmine\plugin\PluginBase;

class FormAPI extends PluginBase{

}
