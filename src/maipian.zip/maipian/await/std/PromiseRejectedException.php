<?php

declare(strict_types=1);

namespace maipian\await\std;

use Exception;

final class PromiseRejectedException extends Exception {}
