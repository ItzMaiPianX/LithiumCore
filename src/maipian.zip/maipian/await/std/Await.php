<?php

namespace maipian\await\std;

use maipian\await\generator\Await as Shaded;

class_alias(Shaded::class, __NAMESPACE__ . "\\Await");
