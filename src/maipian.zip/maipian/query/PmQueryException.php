<?php

namespace maipian\query;

class PmQueryException extends \Exception{
}